# 这个包用于编写处理文本的对象与函数

from .count import word_count
from .cut import CUT_METHODS
from .mood import *
